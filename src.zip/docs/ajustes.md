criar o 'compartihar set'

analisar para implementar o cache universal