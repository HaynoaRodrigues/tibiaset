[plugin:vite:import-analysis] Failed to resolve import "./src/app/page" from "index.tsx". Does the file exist?
C:/Users/mjsan/OneDrive/Área de Trabalho/Haynoã/Projetos/tibiaset/index.tsx:3:17
2  |  import React from "react";
3  |  import { createRoot } from "react-dom/client";
4  |  import Page from "./src/app/page";
   |                    ^
5  |  import "./src/app/globals.css";
6  |  const container = document.getElementById("root");