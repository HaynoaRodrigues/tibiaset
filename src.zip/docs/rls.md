| tablename | rowsecurity | polname                  | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------ | ------ | ------------------- | ---------------- | ------------- |
| ammo      | true        | Permitir leitura em ammo | r      | authenticated, anon | true             | true          |




| tablename       | rowsecurity | polname                             | polcmd | policy_role         | policy_condition | polpermissive |
| --------------- | ----------- | ----------------------------------- | ------ | ------------------- | ---------------- | ------------- |
| amulet_necklace | true        | Permitir leitura em amulet_necklace | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| armor     | true        | Permitir leitura em armor | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                 | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ----------------------- | ------ | ------------------- | ---------------- | ------------- |
| axe       | true        | Permitir leitura em axe | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| boots     | true        | Permitir leitura em boots | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                 | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ----------------------- | ------ | ------------------- | ---------------- | ------------- |
| bow       | true        | Permitir leitura em bow | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                    | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | -------------------------- | ------ | ------------------- | ---------------- | ------------- |
| club      | true        | Permitir leitura em club   | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                     | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | --------------------------- | ------ | ------------------- | ---------------- | ------------- |
| distance  | true        | Permitir leitura em distance| r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                  | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------ | ------ | ------------------- | ---------------- | ------------- |
| extra_slot| true        | Permitir leitura em extra_slot | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                  | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------ | ------ | ------------------- | ---------------- | ------------- |
| fist      | true        | Permitir leitura em fist | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| helmet    | true        | Permitir leitura em helmet| r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| legs      | true        | Permitir leitura em legs  | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                    | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | -------------------------- | ------ | ------------------- | ---------------- | ------------- |
| ring      | true        | Permitir leitura em ring   | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                    | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | -------------------------- | ------ | ------------------- | ---------------- | ------------- |
| rod       | true        | Permitir leitura em rod    | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                    | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | -------------------------- | ------ | ------------------- | ---------------- | ------------- |
| shield    | true        | Permitir leitura em shield | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| spellbook | true        | Permitir leitura em spellbook | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| sword     | true        | Permitir leitura em sword | r      | authenticated, anon | true             | true          |




| tablename | rowsecurity | polname                   | polcmd | policy_role         | policy_condition | polpermissive |
| --------- | ----------- | ------------------------- | ------ | ------------------- | ---------------- | ------------- |
| wand      | true        | Permitir leitura em wand  | r      | authenticated, anon | true             | true          |